const express = require('express')
const fs = require('fs')
const path = require('path')
const { PORT } = require('./constants/env')
const router = require('./routes')
const middlewares = require('./utils/middlewares')
const app = express()

// enable body parsing
middlewares(app)
// add routes
router(app)

app.use('/static', express.static(path.join(__dirname, './build', './static')))
app.use('/', express.static(path.join(__dirname, './build')))

app.get('*', (_, res) => res.sendFile(path.join(__dirname, './build', 'index.html')))

app.listen(PORT, '0.0.0.0', () => console.log(`Example app listening on port ${PORT}!`))
