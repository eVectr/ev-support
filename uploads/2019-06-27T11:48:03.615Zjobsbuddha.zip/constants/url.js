const publicUrls = [
    'uploads',
    'static',
    '/'
]

module.exports = {
    publicUrls
}