module.exports = {
    geoNameEndpoint: 'http://api.geonames.org/search',
    defaultLocationParams: {
        maxRows: 10,
        type: 'json',
        username: 'jobs_buddha_2019'
    }
}