module.exports = {
    consumer_key: '5p6kssa8COfu9eg07jUAZSHPs',  
    consumer_secret: 'dH41JPP1elZSMl3ZvS8B8opVRJu4Jm5EHYUHpOQVdsPdzGa42S',
    access_token: '760125910674731009-JiCxmZhxmGLCDCcCINSRJYtbHPHA4Ed',  
    access_token_secret: '08rqFvuyFCeAvahFbV78TsZ1BEVsXJe9ZD2X45S3zkdkX'
}