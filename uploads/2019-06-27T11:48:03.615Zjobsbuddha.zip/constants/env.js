const PORT = process.env.PORT || 3020

module.exports = {
    PORT
}