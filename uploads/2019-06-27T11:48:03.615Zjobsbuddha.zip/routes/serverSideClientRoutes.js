const express = require('express')
const fs = require('fs')
const path = require('path')
const db = require('../utils/db')
const sitemapUtils = require('../utils/sitemap')
const commonUtils = require('../utils/common')

const serverSideClientRoutes = express.Router()

serverSideClientRoutes.get('/job/:slug', (req, res) => {
    const { slug } = req.params
    const id = commonUtils.decodeSlug(slug)

    db.table('jobs').find({
        _id: id
    }).then(
        records => {
            fs.readFile(path.join(__dirname, '../build', 'index.html'), 'utf8', (err, htmlString) => {
                if (err && !records.length) {
                    res.sendFile(path.join(__dirname, '../build', 'index.html'))
                } else {
                    const html = commonUtils.generateJobMetaHTML(records[0], htmlString, slug)
                    sitemapUtils.appendPageToSitemap(records)
                    res.send(html)
                }
            })
        }
    )

})

module.exports = serverSideClientRoutes