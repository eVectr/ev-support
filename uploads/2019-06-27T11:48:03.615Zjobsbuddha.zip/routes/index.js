const jobsRoutes = require('./jobs')
const applyRoutes = require('./apply')
const uploadRoutes = require('./upload')
const locationRoutes = require('./location')
const sitemapRoutes = require('./sitemap')
const serverSideClientRoutes = require('./serverSideClientRoutes')

module.exports = app => {
    app.use('/jobs', jobsRoutes)
    app.use('/apply', applyRoutes)
    app.use('/upload', uploadRoutes)
    app.use('/location', locationRoutes)
    app.use('/sitemap', sitemapRoutes)
    app.use(serverSideClientRoutes)
}