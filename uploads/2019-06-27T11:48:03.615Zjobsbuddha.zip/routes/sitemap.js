const express = require('express')
const path = require('path')

const sitemapRoutes = express.Router()
const db = require('../utils/db')
const SitemapUtils = require('../utils/sitemap')

sitemapRoutes.post(
    '/generate',
    (req, res) => {
        db.table('jobs').get()
            .then(records => {
                SitemapUtils.appendPageToSitemap(records)
                    .then(() => res.sendFile(path.join(__dirname, '../build', './sitemap.xml')))
                    .catch(() => res.send(500).json({
                        message: 'Server encountered some error while generating the sitemap'
                    }))
            })
    }
)

module.exports = sitemapRoutes