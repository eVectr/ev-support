const express = require('express')

const uploadRoutes = express.Router()

const config = require('../config')

uploadRoutes.post(
    '/',
    config.upload.single('file'),
    (req, res) => {
        res.json({
            uploadUrl: req.file.path
        })
    }
)

module.exports = uploadRoutes