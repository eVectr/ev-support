const express = require('express')
const axios = require('axios')

const { geoNameEndpoint, defaultLocationParams } = require('../constants/location')

const locationRoutes = express.Router()

locationRoutes.get(
    '/',
    (req, res) => {

        const { country, name } = req.query

        axios.get(geoNameEndpoint, {
            params: {
                country,
                name,
                ...defaultLocationParams
            }
        })
        .then(
            ({ data }) =>
                res.status(200)
                    .json({
                        places: (data && data.geonames) || []
                    })
        )
        .catch(
            () =>
                res.status(500).json({
                    message: 'Server encountered an error'
                })
        )

    }
)

module.exports = locationRoutes