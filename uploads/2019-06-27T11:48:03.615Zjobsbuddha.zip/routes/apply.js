const express = require('express')
const axios = require('axios')
const uuidv1 = require('uuid/v1')
const config = require('../config')
const emailUtils = require('../utils/email')
const db = require('../utils/db')

const applyRoutes = express.Router()

const transporter = config.transporter

applyRoutes.post(
    '/',
    (req, res) => {
        db.table('applications').create({
            ...req.body,
            _id: uuidv1(),
            appliedDate: new Date()
        })

        emailUtils.createEmailTemplate(req.body)
            .then(
                html => {
                    const mailOptions = {
                        from: req.body.applicant.email,
                        to: req.body.job.company_email,
                        subject: `Applied for ${req.body.job.position} at JobsBuddha.com`,
                        html
                    };

                    transporter.sendMail(mailOptions, function (err, info) {
                        if(err)
                          res.status(500).json(err)
                        else
                          res.json({
                              message: 'Sent email successfully'
                          });
                    });
                }
            )
    }
)

module.exports = applyRoutes