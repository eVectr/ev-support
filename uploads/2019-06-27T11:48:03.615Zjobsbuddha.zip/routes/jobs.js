const express = require('express')
const uuidv1 = require('uuid/v1')

const twitterUtils = require('../utils/twitter')
const SitemapUtils = require('../utils/sitemap')
const db = require('../utils/db')

const jobsRoutes = express.Router()

jobsRoutes.post(
    '/',
    (req, res) => {
        const job = {
            ...req.body,
            _id: uuidv1(),
            publishedDate: new Date()
        }

        db.table('jobs').create(job)

        if (process.env.NODE_ENV === 'production') {
            twitterUtils.tweet(`${job.company_name} is looking for ${job.position}, are you a great fit for this particular job? Apply at https://jobsbuddha.com/jobs/${job._id} #jobsbuddha #jobs #applytojob`)
            SitemapUtils.appendPageToSitemap([job])
            .then(() => res.json(job))
            .catch(() => res.send(500).json({
                message: 'Server encountered some error while generating the sitemap'
            }))
        }

        if (process.env.NODE_ENV === 'development') {
            res.json(job)
        }
    }
)

jobsRoutes.get(
    '/',
    (req, res) => {
        const { start = 0, limit = 10, searchTerm } = req.query

        const parsedStart = parseInt(start)
        const parsedLimit = parseInt(limit)
        const normalizedStart = parsedStart ? parsedStart - 1 : 0
        const normalizedLimit = normalizedStart + parsedLimit

        let query = {}

        if (searchTerm) {
            query = {
                position: {
                    type: 'regex',
                    pattern: new RegExp(searchTerm, 'i')
                }
            }
        }

        db.table('jobs').find(query).then(
            records => {
                const sortedRecords = records.sort(
                    (firstItem, secondItem) => {
                        if (firstItem.publishedDate == secondItem.publishedDate) {
                            return 0
                        }

                        if (firstItem.publishedDate > secondItem.publishedDate) {
                            return -1
                        }

                        if (firstItem.publishedDate < secondItem.publishedDate) {
                            return 1
                        }
                    }
                )

                res.json({
                    jobs: sortedRecords.slice(normalizedStart, normalizedLimit),
                    total: sortedRecords.length,
                    start,
                    limit
                })
            }
        )
    }
)

jobsRoutes.get(
    '/:id',
    (req, res) =>
        db.table('jobs').find({
            _id: req.params.id
        }).then(
            records => {
                // if job is found
                if (records[0]) {
                    return res.json({
                        job: records[0]
                    })
                
                // else throw an error
                } else {
                    return res.status(404).json({
                        message: 'Job not found'
                    })
                }
            }
        )
)

module.exports = jobsRoutes