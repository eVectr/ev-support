const moment = require('moment')
const xmlJS = require('xml-js')
const path = require('path')
const fs = require('fs')
const CommonUtils = require('../utils/common')

const sitemapPath = path.join(__dirname, '../build', './sitemap.xml')

const getProp = (item, prop) => item.elements.find(element => element.name === prop)

const getUrl = item => {
    return getProp(item, 'loc').elements[0].text.trim()
}

const generateSiteMapItem = job => {
    const location = {
        type: 'element',
        name: 'loc',
        elements: [
            { type: 'text', text: `https://jobsbuddha.com/job/${CommonUtils.createSlug(job)}` }
        ]
    }

    const timeStamp = {
        type: 'element',
        name: 'lastmod',
        elements: [
            { type: 'text', text: moment(job.publishedDate).format() }
        ]
    }

    const sitemapItem = {
        type: 'element',
        name: 'url',
        elements: [
            location,
            timeStamp
        ]
    }

    return sitemapItem
}

const urlExistsInSitemap = (sitemap, item) => {
    const UrlSet = getProp(sitemap, 'urlset')

    return UrlSet.elements.find(
        sitemapItem => {
            return getUrl(sitemapItem) == getUrl(item)
        }
    )
}

const modifySitemapURLS = (sitemap, sitemapItems) => {

    const copyOfSitemap = {...sitemap}

    sitemapItems.forEach(
        sitemapItem => {
            if (!urlExistsInSitemap(sitemap, sitemapItem)) {
                sitemap.elements[0].elements.push(sitemapItem)
            }
        }
    )

    return copyOfSitemap
}

const getSitemap = () => 
    new Promise(
        (resolve, reject) => fs.stat(sitemapPath, err => {
            if (!err) {
                fs.readFile(
                    path.join(__dirname, '../build', './sitemap.xml'),
                    'utf8',
                    (err, data) => {
                        if (err) {
                            return reject(err) 
                        } else {
                            return resolve(data)
                        }
                    }
                )
            } else if(err.code === 'ENOENT') {
                resolve(`
                    <urlset>
                        <url>
                            <loc>https://jobsbuddha.com/</loc>
                            <lastmod>2019-05-31T19:41:59+00:00</lastmod>
                        </url>
                        <url>
                            <loc>https://jobsbuddha.com/post</loc>
                            <lastmod>2019-05-31T19:41:59+00:00</lastmod>
                        </url>
                    </urlset>
                `)
            } else {
                reject(err)
            }
        })
    )

const appendPageToSitemap = jobs => 
    new Promise (
        (resolve, reject) => {
            getSitemap()
                .then(data => {
                    let sitemap = xmlJS.xml2js(data)
                    const sitemapItems = jobs.map(
                        job => generateSiteMapItem(job)
                    )
                    const modifiedSitemap = modifySitemapURLS(sitemap, sitemapItems)
                    const xml = xmlJS.js2xml(modifiedSitemap)

                    fs.writeFile(
                        path.join(__dirname, '../build', './sitemap.xml'),
                        xml,
                        err => {
                            if (err) {
                                reject(err)
                            } else {
                                resolve(sitemap)
                            }
                        }
                    )
                })
                .catch(reject)
        }
    )

module.exports = {
    appendPageToSitemap
}
