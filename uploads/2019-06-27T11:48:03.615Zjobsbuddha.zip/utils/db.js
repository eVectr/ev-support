const protoDB = require('proto-db')
const path = require('path')

const db = new protoDB(path.join(__dirname, '../db'))

db.createStore('jobsBuddha')
db.setStore('jobsBuddha')
db.createTable('jobs')
db.createTable('applications')

module.exports = db