const moment = require('moment')
const cheerio = require('cheerio')
const { publicUrls } = require('../constants/url')

const isPublicRoute = url => publicUrls.find(publicUrl => url.includes(publicUrl) || publicUrl === url)

const createSlug = job => `${encodeURIComponent(job.position).split(' ').join('-')}_~${job._id}`

const decodeSlug = slug => {
    let splitLink = slug.split('_~')
    return splitLink[1]
}

const generateJobMetaHTML = (job, html, slug) => {
    const $ = cheerio.load(html)
    const jobPageTitle = `${job.position} | ${job.company_name}`
    const canonicalURL = `https://www.jobsbuddha.com/job/${slug}`
    const jobDescription = job.messageText.replace(/(\r\n|\n|\r)/gm, '')
    const trimmedDescription = jobDescription.substring(0, 160)

    const jobStructuredData = `
        <script type="application/ld+json">
            {
                "@context" : "https://schema.org/",
                "@type" : "JobPosting",
                "title" : "${job.position} at ${job.company_name}",
                "description" : "<p>${jobDescription}</p>",
                "identifier": {
                    "@type": "PropertyValue",
                    "name": "${job.company_name}",
                    "value": "${job._id}"
                },
                "datePosted" : "${moment(job.publishedDate).format("YYYY-MM-DD")}",
                    "validThrough" : "${moment(job.publishedDate).add(3, 'year').format("YYYY-MM-DD")}",
                    "employmentType" : "CONTRACTOR",
                    "hiringOrganization" : {
                    "@type" : "Organization",
                    "name" : "JobsBuddha",
                    "sameAs" : "https://www.jobsbuddha.com",
                    "logo" : "https://www.jobsbuddha.com/static/media/logo.e121caee.png"
                },
                "jobLocation": {
                    "@type": "Place",
                    "address": {
                        "@type": "PostalAddress",
                        "addressRegion": "${job.cities}",
                        "addressCountry": "${job.location.value}"
                    }
                }
            }
        </script>
    `

    const hydratedJobData = `
        <script type="text/javascript">
            window.SERVER_JOB_DATA = ${JSON.stringify(job)};
        </script>
    `

    const seoMetaTags =  `
        <!-- Twitter Card data -->
        <meta name="twitter:title" content="${jobPageTitle}">
        <meta name="twitter:description" content="${trimmedDescription}">
        <meta name="twitter:creator" content="@recraftrelic">
        <!-- Open Graph data -->
        <meta property="og:title" content="${jobPageTitle}" />
        <meta property="og:url" content="${canonicalURL}" />
        <meta property="og:description" content="${trimmedDescription}" />
        <meta property="og:site_name" content="JobsBuddha" />
        <link rel="canonical" href="${canonicalURL}" />
    `

    $('title').html(`${jobPageTitle}`)
    $("meta[name='description']").attr("content", trimmedDescription);
    $('head').append(seoMetaTags)
    $('head').append(jobStructuredData)
    $('head').append(hydratedJobData)

    return $.html()
}

module.exports = {
    isPublicRoute,
    createSlug,
    decodeSlug,
    generateJobMetaHTML
}