const twit = require('twit')
const twitterConfig = require('../constants/twitter')

const Twitter = new twit(twitterConfig)

const tweet = status => {
    Twitter.post('statuses/update', { status }, function(err, data, response) {
        console.log('Works!')
    })
}

module.exports = {
    tweet
}