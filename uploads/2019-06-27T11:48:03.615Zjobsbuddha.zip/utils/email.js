const path = require('path')
const ejs = require('ejs')

const createEmailTemplate = (data) => {
    const templatePath = path.join(__dirname, '../templates/email.ejs')

    return new Promise (
        (resolve, reject) => {
            ejs.renderFile(templatePath, data, {}, function(err, str){
                if (err) {
                    return reject(err)
                }
                resolve(str)
            });
        }
    )
}

module.exports = {
    createEmailTemplate
}