const path = require('path')
const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const CryptoJS = require('crypto-js')

const CommonUtils = require('../utils/common')

module.exports = app => {
    app.use(bodyParser.json())
    app.use(bodyParser.urlencoded({ extended: true }))
    app.use('/uploads', express.static(path.join(__dirname, '../uploads')))
    app.use(cors())
    app.use(
        (req, res, next) => {
            const { api_key } = req.headers

            if (CommonUtils.isPublicRoute(req.originalUrl)) return next()

            if (!api_key) {
                return res.status(401).json({
                    message: 'Invalid API key'
                })
            } else {
                var bytes = CryptoJS.AES.decrypt(api_key, process.env.SECURE_KEY)
                var plaintext = bytes.toString(CryptoJS.enc.Utf8)

                if (!plaintext) {
                    return res.status(401).json({
                        message: 'Invalid API key'
                    })
                }

                const now = new Date().getTime()
                const apiKeyExpirationTime = parseInt(plaintext) + (60000 * 2)

                if (now > apiKeyExpirationTime) {
                    return res.status(401).json({
                        message: 'API key expired'
                    })  
                }

            }

            next()
        }
    )
}