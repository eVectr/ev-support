const nodemailer = require('nodemailer')
const multer = require('multer')
const uuidv1 = require('uuid/v1')

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'jobsbuddha@gmail.com',
        pass: 'Wuc!wug2'
    }
})

const storage = multer.diskStorage(
    {
        destination: './uploads/',
        filename: function ( req, file, cb ) {
            cb( null, `${uuidv1()}-${file.originalname}` );
        }
    }
);

const upload = multer( { storage: storage } );

module.exports = {
    transporter,
    upload,
    storage
}
